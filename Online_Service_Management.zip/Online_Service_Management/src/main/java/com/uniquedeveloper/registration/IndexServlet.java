package com.uniquedeveloper.registration;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

@WebServlet("/index")
public class IndexServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		String postprodution = request.getParameter("postproduction");
		String installation = request.getParameter("installation");
		String maintenance = request.getParameter("maintenance");
		String follow = request.getParameter("follow");
		String complaint = request.getParameter("complaint");
		String phno = request.getParameter("Phone");
		RequestDispatcher dispatcher = null;
		Connection con = null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/OSM","system","1234");
			PreparedStatement pst = con.prepareStatement("insert into service(name,postproduction,installation,maintenance,follow,complaint,phone) values(?,?,?,?,?,?,?)");
			pst.setString(1, name);
			pst.setString(2, postprodution);
			pst.setString(3, installation);
			pst.setString(4, maintenance);
			pst.setString(5, follow);
			pst.setString(6, complaint);
			pst.setString(7, phno);
			
			int rowCount = pst.executeUpdate();
			
			dispatcher = request.getRequestDispatcher("index.jsp");
			if(rowCount > 0)
			{
				request.setAttribute("status","success");
			}
			else
			{
				request.setAttribute("status","failed");
			}
			dispatcher.forward(request, response);	
		}
		catch(Exception e)
		{
				e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	

}